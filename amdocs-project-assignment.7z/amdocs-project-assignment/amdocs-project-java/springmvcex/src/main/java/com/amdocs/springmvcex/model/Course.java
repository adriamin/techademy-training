package com.amdocs.springmvcex.model;

import lombok.Data;

@Data
public class Course {	
	private String name;
	private String description;
	private String resource;
	private String fees;
}
