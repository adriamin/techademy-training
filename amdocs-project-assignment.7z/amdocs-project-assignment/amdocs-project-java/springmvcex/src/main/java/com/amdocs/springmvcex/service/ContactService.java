package com.amdocs.springmvcex.service;

import com.amdocs.springmvcex.model.Contact;

public interface ContactService {
	public String addContact(Contact contact); // to add new Contact
}
