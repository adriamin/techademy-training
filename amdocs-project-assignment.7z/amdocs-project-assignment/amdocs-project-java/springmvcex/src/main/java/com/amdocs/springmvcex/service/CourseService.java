package com.amdocs.springmvcex.service;

import com.amdocs.springmvcex.model.Course;

public interface CourseService {
	public String addCourse(Course course); // to add new Course
}
