package com.amdocs.springmvcex.service;

import com.amdocs.springmvcex.model.User;

public interface UserService {
	public String addUser(User user); // to add new User
}
