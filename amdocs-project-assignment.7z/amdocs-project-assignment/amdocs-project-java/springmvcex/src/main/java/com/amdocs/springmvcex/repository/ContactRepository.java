package com.amdocs.springmvcex.repository;

import com.amdocs.springmvcex.model.Contact;

public interface ContactRepository {
	public String addContact(Contact contact); // to add new Contact
}
