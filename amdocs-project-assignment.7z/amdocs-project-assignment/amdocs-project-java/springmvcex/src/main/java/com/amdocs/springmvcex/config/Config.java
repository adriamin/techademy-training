package com.amdocs.springmvcex.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class Config {

}
