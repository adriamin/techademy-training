package com.amdocs.springmvcex.repository;

import com.amdocs.springmvcex.model.User;

public interface UserRepository {
	public String addUser(User user); // to add new User
}
