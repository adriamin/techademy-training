package com.amdocs.springmvcex.repository;

import com.amdocs.springmvcex.model.Course;

public interface CourseRepository {
	public String addCourse(Course course); // to add new Course
}
