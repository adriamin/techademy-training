package com.amdocs.springmvcex.repository;

import com.amdocs.springmvcex.model.Feedback;

public interface FeedbackRepository {
	public String addFeedback(Feedback feedback); // to add new feedback
}
