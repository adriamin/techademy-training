package com.amdocs.springmvcex.service;

import com.amdocs.springmvcex.model.Feedback;

public interface FeedbackService {
	public String addFeedback(Feedback feedback); //to add new feedback
}
