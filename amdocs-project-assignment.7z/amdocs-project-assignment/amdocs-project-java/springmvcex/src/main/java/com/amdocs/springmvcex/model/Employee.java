package com.amdocs.springmvcex.model;

import lombok.Data;

@Data
public class Employee {
	private String empId;
	private String firstName;
	private String lastName;
}
